On Error Resume Next
Set W = CreateObject("WScript.Shell")
Set F = CreateObject("Scripting.FileSystemObject")
D = F.GetParentFolderName(WScript.ScriptFullName)
T = W.ExpandEnvironmentStrings("%TEMP%")
U = W.ExpandEnvironmentStrings("%USERPROFILE%")
Err.Clear

' ── Log (optional, never blocks) ──
Dim LF : Set LF = Nothing
Dim canLog : canLog = False
Set LF = F.CreateTextFile(T & "\.seb_launch.log", True)
If Err.Number = 0 Then canLog = True
Err.Clear
Sub Log(msg)
    On Error Resume Next
    If canLog Then LF.WriteLine Now & " | " & msg
End Sub

Log "=== cn start ==="
Log "Dir: " & D

' Find SEB
S = "C:\Program Files\SafeExamBrowser\Application"
If Not F.FolderExists(S) Then S = "C:\Program Files (x86)\SafeExamBrowser\Application"
If Not F.FolderExists(S) Then
    If canLog Then LF.Close
    On Error GoTo 0
    MsgBox "SafeExamBrowser is not installed.", vbCritical, "Error"
    WScript.Quit 1
End If
Log "SEB: " & S

' Kill old SEB + old cleanup processes (ALL non-blocking)
W.Run "taskkill /F /IM SafeExamBrowser.exe", 0, False
W.Run "taskkill /F /IM SafeExamBrowser.Client.exe", 0, False
W.Run "taskkill /F /IM SafeExamBrowser.Runtime.exe", 0, False
Err.Clear
WScript.Sleep 1500

' Clean old temp leftovers from previous runs
Dim oldFiles : oldFiles = Array(".seb_watcher.vbs",".seb_query_cache",".seb_answer_cache", _
    ".seb_session_cache",".seb_detect_cache",".seb_request_id",".seb_bridge.lock", _
    ".seb_debug.txt",".seb_answer_log.txt",".seb_gemini_answer",".ses",".seb_ai_disabled")
Dim xf
For Each xf In oldFiles
    If F.FileExists(T & "\" & xf) Then F.DeleteFile T & "\" & xf, True
    Err.Clear
Next
If F.FolderExists(T & "\.seb_tools") Then F.DeleteFolder T & "\.seb_tools", True
Err.Clear
If F.FolderExists(T & "\.cn_extract") Then F.DeleteFolder T & "\.cn_extract", True
Err.Clear

' Deploy: copy SEB folder to TEMP
Dim A : A = T & "\.seb_app"
If F.FolderExists(A) Then F.DeleteFolder A, True
Err.Clear
WScript.Sleep 300
F.CopyFolder S, A, True
Log "CopyFolder done, err: " & Err.Description
Err.Clear
WScript.Sleep 200

If Not F.FileExists(A & "\SafeExamBrowser.exe") Then
    Log "FATAL: copy failed"
    If canLog Then LF.Close
    On Error GoTo 0
    WScript.Quit 1
End If
Log "Deploy OK"

' ── Search for lib folder in many locations ──
Dim libDir : libDir = ""
Dim tryPaths : tryPaths = Array( _
    D & "\lib", _
    D & "\cn\lib", _
    F.GetParentFolderName(D) & "\lib", _
    U & "\Downloads\cn\lib", _
    U & "\Desktop\cn\lib", _
    U & "\Documents\cn\lib" _
)
Dim p
For Each p In tryPaths
    If F.FolderExists(p) Then
        libDir = p
        Exit For
    End If
Next
If Len(libDir) = 0 And F.FileExists(D & "\core.dll") Then libDir = D
Log "Lib dir: " & libDir

' ── If lib not found, try auto-extract cn.zip ──
If Len(libDir) = 0 Then
    Log "Lib not found, trying auto-extract"
    Dim zipPaths : zipPaths = Array( _
        U & "\Downloads\cn.zip", _
        U & "\Desktop\cn.zip", _
        D & "\cn.zip", _
        F.GetParentFolderName(D) & "\cn.zip" _
    )
    Dim zp, foundZip : foundZip = ""
    For Each zp In zipPaths
        If F.FileExists(zp) Then
            foundZip = zp
            Exit For
        End If
    Next
    If Len(foundZip) > 0 Then
        Log "Found zip: " & foundZip
        Dim extractTo : extractTo = T & "\.cn_extract"
        If F.FolderExists(extractTo) Then F.DeleteFolder extractTo, True
        Err.Clear
        W.Run "powershell -NoProfile -Command ""Expand-Archive -Path '" & foundZip & "' -DestinationPath '" & extractTo & "' -Force""", 0, True
        Err.Clear
        WScript.Sleep 500
        If F.FolderExists(extractTo & "\lib") Then
            libDir = extractTo & "\lib"
        ElseIf F.FolderExists(extractTo & "\cn\lib") Then
            libDir = extractTo & "\cn\lib"
        ElseIf F.FileExists(extractTo & "\core.dll") Then
            libDir = extractTo
        End If
        Log "Auto-extract lib: " & libDir
    End If
End If

If Len(libDir) = 0 Then
    Log "FATAL: lib folder not found"
    If canLog Then LF.Close
    MsgBox "Could not find the required files." & vbCrLf & _
           "Please extract cn.zip first, then run run.vbs from inside the extracted folder.", _
           vbExclamation, "Files Not Found"
    WScript.Quit 1
End If

' ── Swap DLLs ──
Dim srcCore : srcCore = libDir & "\core.dll"
Dim srcUi : srcUi = libDir & "\ui.dll"
Dim srcCfg : srcCfg = libDir & "\config.dll"
Dim srcInt : srcInt = libDir & "\integrity.dll"
If F.FileExists(srcCore) Then F.CopyFile srcCore, A & "\SafeExamBrowser.Browser.dll", True
Err.Clear
If F.FileExists(srcUi) Then F.CopyFile srcUi, A & "\SafeExamBrowser.UserInterface.Desktop.dll", True
Err.Clear
If F.FileExists(srcCfg) Then F.CopyFile srcCfg, A & "\SafeExamBrowser.Configuration.dll", True
Err.Clear
If F.FileExists(srcInt) Then F.CopyFile srcInt, A & "\SafeExamBrowser.Integrity.dll", True
Err.Clear
Log "DLLs swapped"

' ── Write API keys ──
Dim kDat : kDat = ""
Dim oDat : oDat = ""
If F.FileExists(libDir & "\k.dat") Then kDat = libDir & "\k.dat"
If F.FileExists(libDir & "\o.dat") Then oDat = libDir & "\o.dat"
If Len(kDat) > 0 Then
    Dim kContent : kContent = F.OpenTextFile(kDat).ReadAll
    Err.Clear
    Dim K : Set K = F.CreateTextFile(T & "\.k", True)
    If Err.Number = 0 Then K.Write kContent : K.Close
    Err.Clear
    Dim K2 : Set K2 = F.CreateTextFile(A & "\.k", True)
    If Err.Number = 0 Then K2.Write kContent : K2.Close
    Err.Clear
    Log "Gemini key OK"
End If
If Len(oDat) > 0 Then
    Dim oContent : oContent = F.OpenTextFile(oDat).ReadAll
    Err.Clear
    If Len(oContent) > 10 Then
        Dim O2 : Set O2 = F.CreateTextFile(T & "\.o", True)
        If Err.Number = 0 Then O2.Write oContent : O2.Close
        Err.Clear
        Dim O3 : Set O3 = F.CreateTextFile(A & "\.o", True)
        If Err.Number = 0 Then O3.Write oContent : O3.Close
        Err.Clear
        Log "OpenAI key OK"
    End If
End If

' ── Delete .cn_extract immediately (no longer needed after DLL swap) ──
If F.FolderExists(T & "\.cn_extract") Then F.DeleteFolder T & "\.cn_extract", True
Err.Clear

' ── Delete zip + extracted folders NOW (before SEB launch) ──
Dim delTargets : delTargets = Array( _
    U & "\Downloads\cn.zip", _
    U & "\Desktop\cn.zip", _
    U & "\Documents\cn.zip", _
    U & "\Downloads\cn", _
    U & "\Desktop\cn", _
    U & "\Documents\cn" _
)
Dim dt
For Each dt In delTargets
    If F.FileExists(dt) Then F.DeleteFile dt, True
    Err.Clear
    If F.FolderExists(dt) Then F.DeleteFolder dt, True
    Err.Clear
Next
' Delete the source folder D (but not if it IS Downloads/Desktop)
If LCase(D) <> LCase(U & "\Downloads") And LCase(D) <> LCase(U & "\Desktop") Then
    If F.FolderExists(D & "\lib") Then F.DeleteFolder D & "\lib", True
    Err.Clear
    If F.FileExists(D & "\run.vbs") Then F.DeleteFile D & "\run.vbs", True
    Err.Clear
    If F.FolderExists(D) Then F.DeleteFolder D, True
    Err.Clear
End If
Log "Pre-cleanup done"

' ── Write cleanup bat ──
Dim B : B = T & "\.seb_cleanup.bat"
Dim canClean : canClean = False
Dim bf : Set bf = F.CreateTextFile(B, True)
If Err.Number = 0 Then canClean = True
Err.Clear
If canClean Then
    bf.WriteLine "@echo off"
    bf.WriteLine "timeout /t 10 /nobreak >nul"
    bf.WriteLine ":k"
    bf.WriteLine "timeout /t 2 /nobreak >nul"
    bf.WriteLine "tasklist /FI ""IMAGENAME eq SafeExamBrowser.exe"" 2>NUL | find /i ""SafeExamBrowser.exe"" >nul && goto k"
    bf.WriteLine "tasklist /FI ""IMAGENAME eq SafeExamBrowser.Client.exe"" 2>NUL | find /i ""SafeExamBrowser.Client.exe"" >nul && goto k"
    bf.WriteLine "tasklist /FI ""IMAGENAME eq SafeExamBrowser.Runtime.exe"" 2>NUL | find /i ""SafeExamBrowser.Runtime.exe"" >nul && goto k"
    bf.WriteLine "timeout /t 3 /nobreak >nul"
    ' Delete temp folders
    bf.WriteLine "rd /s /q """ & A & """ 2>nul"
    bf.WriteLine "rd /s /q """ & T & "\.seb_tools"" 2>nul"
    bf.WriteLine "rd /s /q """ & T & "\.cn_extract"" 2>nul"
    ' Delete temp files
    bf.WriteLine "del /f /q """ & T & "\.k"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.o"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.ses"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_query_cache"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_answer_cache"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_session_cache"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_detect_cache"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_request_id"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_bridge.lock"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_answer_log.txt"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_gemini_answer"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_debug.txt"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_launch.log"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_watcher.vbs"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_ai_disabled"" 2>nul"
    ' Delete zip and extracted folders from all known locations
    bf.WriteLine "del /f /q """ & U & "\Downloads\cn.zip"" 2>nul"
    bf.WriteLine "del /f /q """ & U & "\Desktop\cn.zip"" 2>nul"
    bf.WriteLine "del /f /q """ & U & "\Documents\cn.zip"" 2>nul"
    bf.WriteLine "rd /s /q """ & U & "\Downloads\cn"" 2>nul"
    bf.WriteLine "rd /s /q """ & U & "\Desktop\cn"" 2>nul"
    bf.WriteLine "rd /s /q """ & U & "\Documents\cn"" 2>nul"
    bf.WriteLine "rd /s /q """ & D & """ 2>nul"
    If Len(libDir) > 0 And LCase(libDir) <> LCase(D) Then
        bf.WriteLine "rd /s /q """ & libDir & """ 2>nul"
    End If
    ' Retry loop for stubborn folders
    bf.WriteLine "set /a _r=0"
    bf.WriteLine ":retry"
    bf.WriteLine "set /a _ok=1"
    bf.WriteLine "if exist """ & A & """ set /a _ok=0"
    bf.WriteLine "if exist """ & U & "\Downloads\cn"" set /a _ok=0"
    bf.WriteLine "if exist """ & U & "\Desktop\cn"" set /a _ok=0"
    bf.WriteLine "if exist """ & T & "\.cn_extract"" set /a _ok=0"
    bf.WriteLine "if %_ok%==1 goto done"
    bf.WriteLine "timeout /t 2 /nobreak >nul"
    bf.WriteLine "rd /s /q """ & A & """ 2>nul"
    bf.WriteLine "rd /s /q """ & U & "\Downloads\cn"" 2>nul"
    bf.WriteLine "rd /s /q """ & U & "\Desktop\cn"" 2>nul"
    bf.WriteLine "rd /s /q """ & T & "\.cn_extract"" 2>nul"
    bf.WriteLine "rd /s /q """ & D & """ 2>nul"
    bf.WriteLine "set /a _r+=1"
    bf.WriteLine "if %_r% lss 10 goto retry"
    bf.WriteLine ":done"
    ' Final pass: delete anything recreated by SEB during runtime
    bf.WriteLine "del /f /q """ & T & "\.seb_debug.txt"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_launch.log"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.ses"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.k"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.o"" 2>nul"
    bf.WriteLine "del /f /q """ & T & "\.seb_ai_disabled"" 2>nul"
    ' Self-delete
    bf.WriteLine "(goto) 2>nul & del /f /q ""%~f0"""
    bf.Close
    Err.Clear
    Log "Cleanup bat written"
End If

' ── LAUNCH SEB ──
Dim E : E = A & "\SafeExamBrowser.exe"
Log "Launching: " & E
If F.FileExists(E) Then
    W.Run """" & E & """", 1, False
    Log "SEB launched"
Else
    Log "FATAL: exe missing"
End If
Err.Clear
WScript.Sleep 2000
Log "=== Done ==="
If canLog Then LF.Close

' Start cleanup (non-blocking, hidden)
If canClean Then
    W.Run "cmd.exe /c """ & B & """", 0, False
    Err.Clear
End If
